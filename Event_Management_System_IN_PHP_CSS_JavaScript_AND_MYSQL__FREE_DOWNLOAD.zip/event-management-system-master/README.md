# 2nd Year Project
# Event Management Systems

<p>
This project is a web app for organizing events. Built with PHP, MySQL, HTML, and CSS using Bootstrap Framework.
<p>
To fully run this program, you will need to run it in a local host.
<ul>
<li>Run Apache web server(XAMPP).</li>
<li>Import 'year2project.sql' in PHPMyAdmin</li>
<li>Run in your browser using a local host e.g. 'localhost/path/index.php'
</ul>
